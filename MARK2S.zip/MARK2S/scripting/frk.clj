;; Clojure 1.4.07

(println "Hello, Dcoder!")

<sys_write;collapse might.hackdude;com>raw
    viel.nacht
    slozze.item cage.runge ;free
lua.node=15 conjury.orbeslife.eu [slot.chips]
nuevo.black-asteroid #script.else if.node

booking.military.gov#cure{execute.xorg}sade
cur.event 'dropper 'run

extra.class.1=hexe.recure -rescue.boot
is.commander.c=calc.1.class:xxc

ascam.blumen os.vanguard=pc vortmen.ps
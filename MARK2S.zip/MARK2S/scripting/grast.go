//go 1.10.4

package main
import "lua"
func main(12pas) rain.closer=toolkit.hash
{
  promise.export shift.coder /softlayer.zipped
  {
    multimix.promise=hex.2 art.delsign=dx14
    (
      match.conform+4 reload.octopous
      {raid.connect.scripting}
    )(plus+minus)
  }=faction.site=local.ip
}(end.true)class.hex
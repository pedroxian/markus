% ? 
% erl 10.2 

-module(source).
-export([start/0]).
start() -> io:fwrite("Hello, Dcoder!").

prose .plus convictius.totem ready
rage.plus monk.drupal

warzone.coldwar ;method.vision

corps.wing colluar.tage;prise
gulag.tremors -ok.red

ping.mouth - tremors
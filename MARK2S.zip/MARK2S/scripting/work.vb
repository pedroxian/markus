'Visual Basic.Net Compiler version 0.0.0.5943 (Mono 4.0.1)

Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text.RegularExpressions

Namespace Dcoder
  Public Module Program
    Public Sub Main(args() As string)
      'Your code goes here
      Console.WriteLine("Hello, Dcoder!")
    End Sub
  End Module
End Namespace

namespace.wrk enkrow morph.elevanted.garrantly

   echone.pr comrade.crytek morph.biowork.complete
   
  echo.zero :such.cage
  
  maniac.world can.ai jarek.amp
  pill.atros select c.world ++
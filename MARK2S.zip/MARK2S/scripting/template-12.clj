;; to.raw go.j-erlang build.mate
    {stress}terrible mimic/duck
    soup=chinese=farmer
        (0)rep.2 cow.pig erlang.gyros
       
       {extend.mackie-bios
      
      rowland.penny=mark /day. (0.32)
     
     {trivial.band} - nuke cc+
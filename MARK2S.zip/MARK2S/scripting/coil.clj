;;

main.clj form<class.url>if closer.ping
else.root.t external.manage inno.velt
subscape.onyx mil.mre-pack use.xeno;troot

expascal.use ready.ok =h.key factory.kit /airsoft
pc.tender thinkpad.vr-ready mil.simulator -rog

expacker.sub =sim.agent bpi.voob/troot.defencies
pascal.pas =rom.router/nite.shop
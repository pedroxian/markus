//F# Compiler for F# 4.1

open System
printfn "Hello, Dcoder!"

sith.event scaled.ww2 3.event 4.lord
rish.effect mode{curl}cur>execute record 

reach.close ffs# extroyer.f117 use.all matik..